from django.apps import AppConfig


class StockpickerConfig(AppConfig):
    name = 'stockpicker'
